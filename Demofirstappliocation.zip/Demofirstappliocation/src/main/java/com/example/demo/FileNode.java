package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class FileNode {
	String name; // name of the file or folder
    boolean isFile;
    List<FileNode> children; // sub-folders and files

    FileNode(String name, boolean isFile) {
        this.name = name;
        this.isFile = isFile;
        this.children = new ArrayList<>();
    }
}