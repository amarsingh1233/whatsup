package com.example.demo;

public class Calculation {
	private String calculateField;
    private String formula;
	public String getCalculateField() {
		return calculateField;
	}
	public void setCalculateField(String calculateField) {
		this.calculateField = calculateField;
	}
	public String getFormula() {
		return formula;
	}
	public void setFormula(String formula) {
		this.formula = formula;
	}
	@Override
	public String toString() {
		return "Calculation [calculateField=" + calculateField + ", formula=" + formula + ", getCalculateField()="
				+ getCalculateField() + ", getFormula()=" + getFormula() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
