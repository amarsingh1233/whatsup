package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class CalculationController {

	 @PostMapping("/process")
	    public Map<String, Double> processCalculations(@RequestBody List<Calculation> calculations) throws ScriptException {
	        Map<String, Double> fieldValues = new HashMap<>();
	        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");

	        for (Calculation calculation : calculations) {
	            String field = calculation.getCalculateField();
	            String formula = calculation.getFormula();

	            for (String key : fieldValues.keySet()) {
	                formula = formula.replace(key, fieldValues.get(key).toString());
	            }

	            Double result = (Double) engine.eval(formula);
	            fieldValues.put(field, result);
	        }

	        return fieldValues;
	    }
	}